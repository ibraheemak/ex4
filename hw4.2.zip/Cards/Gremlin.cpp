
#include <algorithm>
#include "../Players/Player.h"
#include "BattleCard.h"
#include "Gremlin.h"
using namespace std;

Gremlin::Gremlin(): BattleCard(GREMLIN,DEFAULT_POWER,DEFAULT_LOOT,DEFAULT_DAMAGE){}

