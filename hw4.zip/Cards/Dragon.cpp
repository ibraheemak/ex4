
#include <algorithm>
#include "../Players/Player.h"
#include "BattleCard.h"
#include "Dragon.h"
using namespace std;

Dragon::Dragon(): BattleCard(DRAGON,DEFAULT_POWER,DEFAULT_LOOT,DEFAULT_DAMAGE){}
